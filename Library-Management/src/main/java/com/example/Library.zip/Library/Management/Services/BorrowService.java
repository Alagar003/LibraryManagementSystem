package com.example.Library.Management.Services;

import com.example.Library.Management.Dal.BorrowManagement;
import com.example.Library.Management.Model.BorrowRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class BorrowService {

    private BorrowManagement borrowDao;

    @Autowired
    public BorrowService(BorrowManagement borrowDao) {
        this.borrowDao = borrowDao;
    }

    public String addBorrowRecord(String memberId, String isbn) {
        return borrowDao.addBorrowRecord(memberId, isbn);
    }

    public String returnBook(String memberId, String isbn) {
        return borrowDao.returnBook(memberId, isbn);
    }

    public List<String> getBorrowedBooksByMemberId(String memberId) {
        return borrowDao.getBorrowedBooksByMemberId(memberId);
    }

    public Map<String, BorrowRecord> getAllBorrowedRecords() {
        return borrowDao.getAllBorrowedRecords();
    }
}
