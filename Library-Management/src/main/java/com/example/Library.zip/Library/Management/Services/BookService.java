package com.example.Library.Management.Services;

import com.example.Library.Management.Dal.BookManagement;
import com.example.Library.Management.Model.Book;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookService {

    @Autowired
    private  BookManagement bookDao;
    public Book addBook(Book book) {
        return bookDao.addBook(book);
    }

    public Book getBookByIsbn(String isbn) {
        return bookDao.getBookByIsbn(isbn);
    }

    public List<Book> getAllBooks() {
        return bookDao.getAllBooks();
    }

    public boolean updateBook(String isbn, Book book) {
        return bookDao.updateBook(book);
    }

    public boolean removeBook(String isbn) {
        return bookDao.removeBook(isbn);
    }
}
