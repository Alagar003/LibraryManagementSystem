package com.example.Library.Management.Dal;

import com.example.Library.Management.Model.BorrowRecord;

import java.util.List;
import java.util.Map;

public interface BorrowManagement {
    String addBorrowRecord(String memberId, String isbn);
    String returnBook(String memberId, String isbn);
    List<String> getBorrowedBooksByMemberId(String memberId);
    Map<String, BorrowRecord> getAllBorrowedRecords();
}
