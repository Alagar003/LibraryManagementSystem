package com.example.Library.Management.Dal;

import com.example.Library.Management.Model.Book;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;


@Repository
public class BookDao implements BookManagement {

    private  Map<String, Book> books = new ConcurrentHashMap<>();

    @Override
    public Book addBook(Book book) {
        if (book == null || book.getIsbn() == null) {
            throw new IllegalArgumentException("Book or ISBN cannot be null");
        }
        books.putIfAbsent(book.getIsbn(), book);
        System.out.println(book.getIsbn());
        return book;
    }

    public Book getBookByIsbn(String isbn) {
        if (isbn == null) {
            throw new IllegalArgumentException("ISBN cannot be null");
        }
        return books.get(isbn); // Assuming bookMap is your ConcurrentHashMap
    }


    @Override
    public List<Book> getAllBooks() {
        return new ArrayList<>(books.values());
    }

    @Override
    public boolean updateBook(Book book) {
        return books.replace(book.getIsbn(), book) != null;
    }

    @Override
    public boolean removeBook(String isbn) {
        return books.remove(isbn) != null;
    }
}
