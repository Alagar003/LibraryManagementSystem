package com.example.Library.Management.Dal;

import com.example.Library.Management.Model.Book;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface BookManagement {
    Book addBook(Book book);
    Book getBookByIsbn(String isbn);
    List<Book> getAllBooks();
    boolean updateBook(Book book);
    boolean removeBook(String isbn);
}
