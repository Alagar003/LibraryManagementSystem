package com.example.Library.Management.Dal;

import com.example.Library.Management.Model.Book;
import com.example.Library.Management.Model.BorrowRecord;
import com.example.Library.Management.Model.Member;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class BorrowDao implements BorrowManagement {
    private Map<String,BorrowRecord> Borrows = new HashMap<>();
    private Map<String, List<String>> MemberBorrowed = new HashMap<>();

    @Autowired
    private BookDao bookDao; // Assuming BookDao is available for book operations
    @Autowired
    private MemberDao memberDao; // Assuming MemberDao is available for member operations

    @Override
    public String addBorrowRecord(String memberId, String isbn) {
        // Get the member and book details
        Member member = memberDao.getMemberById(memberId);
        Book book = bookDao.getBookByIsbn(isbn);

        // Check if the member and book exist
        if (member == null) {
            return "Member not found.";
        }
        if (book == null) {
            return "Book not found.";
        }

        // Check if the book is available
        if (!book.isAvailable()) {
            return "Book is currently unavailable.";
        }

        // Create a new borrow record
        String borrowId = generateRecordId();
        BorrowRecord borrowRecord = new BorrowRecord(borrowId, memberId, isbn, LocalDate.now(), LocalDate.now().plusDays(14));

        // Mark the book as unavailable
        book.setAvailable(false);
        book.setBorrowerId(borrowId);

        // Add the borrow record to the borrowRecordHashMap
        Borrows.put(borrowId, borrowRecord);

        // Add the borrow record to the member's borrowed books list
        MemberBorrowed.computeIfAbsent(memberId, k -> new ArrayList<>()).add(borrowId);

        return "Borrowing successful: " + borrowRecord.toString(); // Borrowing was successful
    }
    @Override
    public String returnBook(String memberId, String isbn) {


        Book book = bookDao.getBookByIsbn(isbn);

        if(MemberBorrowed.containsKey(memberId) ) {

            List<String> list = new ArrayList<>();

            for(String borrowId : MemberBorrowed.get(memberId)) {
                if(!borrowId.equals(book.getBorrowerId())) {
                    list.add(borrowId);
                }
            }
            MemberBorrowed.put(memberId,list);

            LocalDate lastdate = Borrows.get(book.getBorrowerId()).getEndDate();
            book.setAvailable(true);
            book.setBorrowerId("null");
            if(lastdate.isBefore(LocalDate.now())) {
                long daysBetween = ChronoUnit.DAYS.between(lastdate, LocalDate.now());
                return "Fine "+ daysBetween*(20);
            }else {
                return "Success";
            }
        }else {
            return "member invalid";
        }
    }

    @Override
    public List<String> getBorrowedBooksByMemberId(String memberId) {
        List<String> list = new ArrayList<>();
        for(String id : MemberBorrowed.get(memberId)){
            list.add(Borrows.get(id).getIsbn() + bookDao.getBookByIsbn(Borrows.get(id).getIsbn()).getTitle());
        }
        return list;
    }

    @Override
    public Map<String,BorrowRecord> getAllBorrowedRecords() {
        return Borrows;
    }

    // Helper method to generate a unique borrow record ID
    private String generateRecordId() {
        return "BR" + (Borrows.size() + 1);
    }
}
